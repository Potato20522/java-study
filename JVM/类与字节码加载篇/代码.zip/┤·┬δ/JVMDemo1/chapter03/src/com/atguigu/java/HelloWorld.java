package com.atguigu.java;

/**
 * @author shkstart
 * @create 2020-09-13 15:31
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("hello,world!");
    }
}
