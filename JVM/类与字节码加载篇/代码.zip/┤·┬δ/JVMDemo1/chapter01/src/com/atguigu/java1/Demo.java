package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2020-08-31 8:52
 * 全类名：com.atguigu.java1.Demo
 * 全限定名：com/atguigu/java1/Demo
 */
public class Demo {
    private int num = 1;

    public int add(){
        num = num + 2;
        return num;

    }
}
