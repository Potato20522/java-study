package com.atguigu.java1;

/**
 * @author shkstart
 * @create 11:07
 */
public class Demo1 {
    public void hot() {
        System.out.println("OldDemo1---> NewDemo1");
    }

}
