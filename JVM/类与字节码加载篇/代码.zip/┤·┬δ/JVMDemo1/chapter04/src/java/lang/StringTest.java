package java.lang;

/**
 * @author shkstart
 * @create 9:41
 */
public class StringTest {
    public static void main(String[] args) {
        String str = new String();
    }
}
